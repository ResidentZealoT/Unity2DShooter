﻿using UnityEngine;
using System.Collections;

public class Destroyer : MonoBehaviour {

	void DestroyGameObject()
	{
		Destroy (gameObject);
	}
}
